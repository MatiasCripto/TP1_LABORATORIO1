/*
 ============================================================================
 Name        : recu2do.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "LinkedList"

typedef struct
{
	int id;
	char marca[20];
	int tipo;
	float peso;
}eVehiculo;



eVehiculo* vehiculo_new();
eVehiculo* vehiculo_newParametros(char* idStr,char* marcaStr,char* tipoStr, char* pesoStr);
int controller_guardarVehiculossModoTexto(char* path , LinkedList* pArrayListVehiculo);
int controller_guardarVehiculosModoBinario(char* path , LinkedList* pArrayListVehiculo);

int main(void) {
	setbuf(stdout,NULL);
	LinkedList* lista=ll_newLinkedList();

	eVehiculo v1 = {123,"Ford",5,650.14};


	return EXIT_SUCCESS;
}
eVehiculo* vehiculo_new()
	{
		eVehiculo* nuevoVehiculo;
		nuevoVehiculo = (eVehiculo*)malloc(sizeof(eVehiculo));
		    if(nuevoVehiculo != NULL)
		    {
		    	nuevoVehiculo->id = 0;

		        strcpy(nuevoVehiculo->marca," ");

		        nuevoVehiculo->tipo = 0;

		        nuevoVehiculo->peso = 0;

		    }

		    return nuevoVehiculo;
	}
	eVehiculo* vehiculo_newParametros(char* idStr,char* marcaStr,char* tipoStr, char* pesoStr)
	{
		eVehiculo* nuevoVehiculo;
		nuevoVehiculo = vehiculo_new();

		    if(nuevoVehiculo != NULL)
		    {
		        if(!(vehiculo_setId(nuevoVehiculo,atoi(idStr))&&
		        		vehiculo_setMarca(nuevoVehiculo, marcaStr)&&
						jug_setTipo(nuevoVehiculo,atoi(tipoStr))&&
		                jug_setIdpeso(nuevoVehiculo,atof(pesoStr))))
		        {
		            jug_delete(nuevoVehiculo);
		            nuevoVehiculo = NULL;
		        }
		    }

		    return nuevoVehiculo;
	}




int controller_guardarVehiculossModoTexto(char* path , LinkedList* pArrayListVehiculo)
{
	int retorno = 0;

	FILE* pFile;

	if (path != NULL && pArrayListVehiculo != NULL)
	{
		pFile = fopen(path,"w");
		if(pFile == NULL)
		{
			printf("\nEl archivo no pudo abrirse.\n");
			exit (1);
		}
		else
		{
			parser_VehiculoToText(pFile , pArrayListVehiculo);
			retorno = 1;
		}

	}
	fclose(pFile);
	return retorno;
}
int controller_guardarVehiculosModoBinario(char* path , LinkedList* pArrayListVehiculo)
{
	int retorno = 0;
	int limite;
	int i = 0;
	eVehiculo*  vehiculo = NULL;
	FILE* pFile;

	if (path != NULL && pArrayListVehiculo != NULL && ll_isEmpty(pArrayListVehiculo) != 1)
	{
		pFile = fopen(path,"wb");
		if(pFile == NULL)
		{
			printf("\nEl archivo no pudo abrirse.\n");
			exit (1);
		}
		limite =ll_len(pArrayListVehiculo);
		for (i = 0; i < limite;i++ )
		{
			vehiculo = ll_get(pArrayListVehiculo,i);
			if (vehiculo != NULL)
			{
				fwrite(vehiculo, sizeof(eVehiculo),1,pFile);
				retorno = 1;
			}
			else
			{
				vehiculo = NULL;
			}
		}
	}
	fclose(pFile);
	return retorno;
}
